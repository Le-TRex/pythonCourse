# Jeu de dés

import random
score = 0


def de():
    return random.randint(1, 6)


def maximum(liste):
    if not liste:
        return None
    max = liste[0]
    for element in liste:
        if element > max:
            max = element
    return max


def points(de1, de2, de3):
    global score
    if de1 == de2 == de3:
        score += 1
        return score
    elif de1 == de2:
        score += 3 * de3
        return score
    elif de2 == de3:
        score += 3 * de1
        return score
    elif de1 == de3:
        score += 3 * de2
        return score
    elif de1 != de2 != de3:
        des = [de1]
        des.append(de2)
        des.append(de3)
        score += maximum(des)
        return score


def tour():
    de1 = de()
    de2 = de()
    de3 = de()

    print("dé 1 :", de1)
    print("dé 2 :", de2)
    print("dé 3 :", de3)

    points(de1, de2, de3)
    print("score :", score)

    de_a_relancer = input("relancer un dé ?\n 1 pour dé 1 \n 2 pour dé 2 \n 3 pour dé 3\n n'importe quelle touche pour non.")

    if de_a_relancer > "3":
        print("ok ! Score :", score)
        return score
    elif de_a_relancer == "1":
        de1 = de()
    elif de_a_relancer == "2":
        de2 = de()
    elif de_a_relancer == "3":
        de3 = de()
    print("dé 1 :", de1)
    print("dé 2 :", de2)
    print("dé 3 :", de3)
    points(de1, de2, de3)
    print("score :", score)


# def partie():
#     nombre_de_tour = 0
#     while nombre_de_tour != 3:
#         tour()
#         nombre_de_tour +=1


tour()


